import React from 'react';

const Hero = () => {
  // Inline styles
  const styles = {
    hero: {
      padding: '120px 0 80px',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      marginTop: '60px',
    },
    container: {
      display: 'flex',
      alignItems: 'center',
      gap: '3rem',
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '0 20px',
    },
    heroContent: {
      flex: 1,
    },
    heroTitle: {
      fontSize: '3.5rem',
      fontWeight: 700,
      marginBottom: '1.5rem',
      lineHeight: 1.2,
    },
    heroTitleSpan: {
      color: '#fbbf24',
    },
    heroDescription: {
      fontSize: '1.25rem',
      marginBottom: '2rem',
      opacity: 0.9,
      lineHeight: 1.6,
    },
    heroButtons: {
      display: 'flex',
      gap: '1rem',
    },
    heroImage: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
    },
    imagePlaceholder: {
      width: '400px',
      height: '300px',
      background: 'rgba(255,255,255,0.1)',
      borderRadius: '20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backdropFilter: 'blur(10px)',
      border: '1px solid rgba(255,255,255,0.2)',
    },
    imagePlaceholderText: {
      fontSize: '1.5rem',
      fontWeight: 600,
      opacity: 0.8,
    }
  };

  return (
    <section id="home" className="hero" style={styles.hero}>
      <div className="container" style={styles.container}>
        <div className="hero-content" style={styles.heroContent}>
          <h1 className="hero-title" style={styles.heroTitle}>
            Welcome to <span style={styles.heroTitleSpan}>EZ-Task</span>
          </h1>
          <p className="hero-description" style={styles.heroDescription}>
            We build innovative solutions that transform businesses and create exceptional digital experiences.
            Let's create something amazing together.
          </p>
          <div className="hero-buttons" style={styles.heroButtons}>
            <a href="#contact" className="btn btn-primary">
              Get Started
            </a>
            <a href="#about" className="btn btn-secondary">
              Learn More
            </a>
          </div>
        </div>
        
        <div className="hero-image" style={styles.heroImage}>
          <div className="image-placeholder" style={styles.imagePlaceholder}>
            <span style={styles.imagePlaceholderText}>Innovation Starts Here</span>
          </div>
        </div>
      </div>

      {/* Add responsive styles that can't be easily done with inline styles */}
      <style>
        {`
          @media (max-width: 768px) {
            .hero .container {
              flex-direction: column !important;
              text-align: center;
            }
            
            .hero-title {
              font-size: 2.5rem !important;
            }
            
            .hero-description {
              font-size: 1.125rem !important;
            }
            
            .hero-buttons {
              justify-content: center !important;
              flex-wrap: wrap !important;
            }
            
            .image-placeholder {
              width: 100% !important;
              max-width: 300px !important;
              height: 200px !important;
            }
            
            .image-placeholder span {
              font-size: 1.25rem !important;
            }
          }
          
          @media (max-width: 480px) {
            .hero {
              padding: 100px 0 60px !important;
            }
            
            .hero-title {
              font-size: 2rem !important;
            }
            
            .hero-description {
              font-size: 1rem !important;
            }
            
            .hero-buttons {
              flex-direction: column !important;
              align-items: center !important;
            }
            
            .hero-buttons .btn {
              width: 100% !important;
              max-width: 200px !important;
            }
          }
        `}
      </style>
    </section>
  );
};

export default Hero;