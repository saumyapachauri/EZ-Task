import React, { useState } from 'react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Inline styles
  const styles = {
    header: {
      background: 'white',
      boxShadow: '0 2px 20px rgba(0,0,0,0.1)',
      position: 'fixed',
      width: '100%',
      top: 0,
      zIndex: 1000,
    },
    container: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '0 2rem',
    },
    nav: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1.5rem 0',
      gap: '4rem',
    },
    logo: {
      color: '#2563eb',
      fontWeight: 700,
      fontSize: '1.8rem',
      margin: 0,
      letterSpacing: '-0.5px',
    },
    navLinks: {
      display: 'flex',
      gap: '3.5rem',
      alignItems: 'center',
    },
    navLink: {
      textDecoration: 'none',
      color: '#374151',
      fontWeight: 600,
      transition: 'all 0.3s ease',
      fontSize: '1.1rem',
      padding: '0.75rem 0',
      position: 'relative',
    },
    menuToggle: {
      display: 'none',
      flexDirection: 'column',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      gap: '5px',
      padding: '0.5rem',
      transition: 'transform 0.3s ease',
    },
    menuSpan: {
      width: '25px',
      height: '3px',
      background: '#374151',
      transition: 'all 0.3s ease',
      borderRadius: '2px',
    }
  };

  return (
    <header style={styles.header}>
      <div style={styles.container}>
        <nav style={styles.nav}>
          <div className="logo-section">
            <div className="logo">
              <h2 style={styles.logo}>EZ-Task</h2>
            </div>
          </div>
          
          <div className="navigation-section">
            <div 
              className={`nav-links ${isMenuOpen ? 'nav-links-active' : ''}`}
              style={styles.navLinks}
            >
              <a 
                href="#home" 
                style={styles.navLink}
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </a>
              <a 
                href="#about" 
                style={styles.navLink}
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </a>
              <a 
                href="#services" 
                style={styles.navLink}
                onClick={() => setIsMenuOpen(false)}
              >
                Services
              </a>
              <a 
                href="#contact" 
                style={styles.navLink}
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </a>
            </div>

            <button 
              className={`menu-toggle ${isMenuOpen ? 'active' : ''}`}
              style={styles.menuToggle}
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <span style={styles.menuSpan}></span>
              <span style={styles.menuSpan}></span>
              <span style={styles.menuSpan}></span>
            </button>
          </div>
        </nav>
      </div>

      {/* Add the CSS for dynamic classes that can't be inline styled */}
      <style>
        {`
          .nav-links a:hover {
            color: #2563eb;
            transform: translateY(-1px);
          }
          
          .nav-links a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 3px;
            background: linear-gradient(90deg, #2563eb, #3b82f6);
            transition: width 0.3s ease;
            border-radius: 2px;
          }
          
          .nav-links a:hover::after {
            width: 100%;
          }
          
          .menu-toggle:hover {
            transform: scale(1.1);
          }
          
          .menu-toggle:hover span {
            background: #2563eb;
          }
          
          .menu-toggle.active span:nth-child(1) {
            transform: rotate(45deg) translate(6px, 6px);
          }
          
          .menu-toggle.active span:nth-child(2) {
            opacity: 0;
          }
          
          .menu-toggle.active span:nth-child(3) {
            transform: rotate(-45deg) translate(6px, -6px);
          }
          
          @media (max-width: 768px) {
            .menu-toggle {
              display: flex !important;
            }
            
            .nav-links {
              position: absolute;
              top: 100%;
              left: 0;
              width: 100%;
              background: white;
              flex-direction: column;
              padding: 1.5rem 0;
              box-shadow: 0 10px 25px rgba(0,0,0,0.15);
              transform: translateY(-20px);
              opacity: 0;
              visibility: hidden;
              transition: all 0.4s ease;
              gap: 0;
            }
            
            .nav-links a {
              padding: 1.25rem 2rem;
              width: 100%;
              text-align: center;
              font-size: 1.2rem;
              border-bottom: 1px solid #f1f5f9;
              transition: all 0.3s ease;
            }
            
            .nav-links a:hover {
              background: #f8fafc;
              transform: none;
              color: #2563eb;
            }
            
            .nav-links a:last-child {
              border-bottom: none;
            }
            
            .nav-links a::after {
              display: none;
            }
            
            .nav-links-active {
              transform: translateY(0);
              opacity: 1;
              visibility: visible;
            }
          }
          
          @media (max-width: 480px) {
            .container {
              padding: 0 1rem;
            }
            
            .nav {
              padding: 0.8rem 0;
            }
            
            .logo h2 {
              font-size: 1.3rem;
            }
            
            .nav-links a {
              padding: 1rem 1.5rem;
              font-size: 1.1rem;
            }
          }
        `}
      </style>
    </header>
  );
};

export default Header;