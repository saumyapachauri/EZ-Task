import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3>EZ-Task</h3>
            <p>Building innovative solutions for the future.</p>
          </div>
          
          <div className="footer-section">
            <h4>Quick Links</h4>
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#contact">Contact</a>
          </div>
          
          <div className="footer-section">
            <h4>Connect</h4>
            <a href="#">LinkedIn</a>
            <a href="#">Twitter</a>
            <a href="#">GitHub</a>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; 2025 EZ-Task. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;