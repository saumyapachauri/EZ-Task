import React, { useState } from 'react';
import axios from 'axios';
import './ContactForm.css'; // Import the CSS file

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  // Initial form state for reset
  const initialFormData = {
    name: '',
    email: '',
    phone: '',
    message: ''
  };

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  // FORM RESET FUNCTION
  const resetForm = () => {
    setFormData({ ...initialFormData });
    setErrors({});
    setSubmitStatus('');
  };

  // STEP 1: EMPTY FORM VALIDATION - Front-end validation
  const validateForm = () => {
    const newErrors = {};

    // Name validation - Empty check
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    // Email validation - Empty check + Format validation
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Phone validation - Empty check + 10 digits validation
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else {
      const phoneDigits = formData.phone.replace(/\D/g, '');
      if (phoneDigits.length !== 10) {
        newErrors.phone = 'Phone number must be exactly 10 digits';
      }
    }

    // Message validation - Empty check
    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    }

    return newErrors;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // STEP 2: PREVENT EMPTY FORM SUBMISSION
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      
      // Scroll to first error
      const firstErrorField = Object.keys(validationErrors)[0];
      const element = document.getElementById(firstErrorField);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        element.focus();
      }
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus('');

    try {
      console.log('Submitting form data:', formData);
      
      const response = await axios.post(
        'https://vernanbackend.ezlab.in/api/contact-us/', 
        {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          message: formData.message
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: 10000
        }
      );

      console.log('API Response:', response);

      // STEP 3: HANDLE SUCCESS - Check for status 201 (Created)
      if (response.status === 201) {
        setSubmitStatus('success');
        
        // RESET FORM AFTER SUCCESSFUL SUBMISSION
        resetForm();
        
        // Auto-hide success message after 5 seconds
        setTimeout(() => {
          setSubmitStatus('');
        }, 5000);
      } else {
        // Handle other success status codes if needed
        console.warn('Unexpected status code:', response.status);
        setSubmitStatus('success'); // Still consider it success
        resetForm();
      }

    } catch (error) {
      console.error('API Error:', error);
      
      if (error.response) {
        // Server responded with error status
        console.error('Error Response Data:', error.response.data);
        console.error('Error Status:', error.response.status);
        
        if (error.response.status === 400) {
          setSubmitStatus('validation-error');
        } else {
          setSubmitStatus('error');
        }
      } else if (error.request) {
        // Request was made but no response received
        console.error('No Response Received:', error.request);
        setSubmitStatus('network-error');
      } else {
        // Other errors
        console.error('Error:', error.message);
        setSubmitStatus('error');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="section contact-section">
      <div className="container">
        <div className="contact-header">
          <h2 className="section-title">Get In Touch</h2>
          <p className="section-subtitle">
            Have a project in mind? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
          </p>
        </div>

        <div className="contact-content">
          <div className="contact-info">
            <h3>Let's Talk</h3>
            <p>
              We're here to help you bring your ideas to life. Whether you need a web application, 
              mobile app, or digital transformation, we've got you covered.
            </p>
            
            <div className="contact-details">
              <div className="contact-item">
                <strong>Email</strong>
                <span>contact@ezlabs.com</span>
              </div>
              <div className="contact-item">
                <strong>Phone</strong>
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="contact-item">
                <strong>Address</strong>
                <span>123 Innovation Drive, Tech City</span>
              </div>
            </div>
          </div>

          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            {/* STEP 4: SUCCESS MESSAGE - Show "Form Submitted" on status 201 */}
            {submitStatus === 'success' && (
              <div className="success-message">
                <div className="message-icon">✅</div>
                <div className="message-content">
                  <strong>Form Submitted Successfully!</strong>
                  <p>Thank you for your message. We'll get back to you soon.</p>
                </div>
              </div>
            )}
            
            {/* Error Messages */}
            {submitStatus === 'error' && (
              <div className="error-message">
                <div className="message-icon">❌</div>
                <div className="message-content">
                  <strong>Submission Failed</strong>
                  <p>There was an error submitting the form. Please try again.</p>
                </div>
              </div>
            )}
            
            {submitStatus === 'network-error' && (
              <div className="error-message">
                <div className="message-icon">📡</div>
                <div className="message-content">
                  <strong>Network Error</strong>
                  <p>Please check your internet connection and try again.</p>
                </div>
              </div>
            )}

            {submitStatus === 'validation-error' && (
              <div className="error-message">
                <div className="message-icon">⚠️</div>
                <div className="message-content">
                  <strong>Validation Error</strong>
                  <p>Please check your input and try again.</p>
                </div>
              </div>
            )}

            {/* Form Fields */}
            <div className="form-group">
              <label htmlFor="name">Full Name *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className={errors.name ? 'error' : ''}
                placeholder="Enter your full name"
                disabled={isSubmitting}
              />
              {errors.name && <span className="error-text">{errors.name}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="email">Email Address *</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className={errors.email ? 'error' : ''}
                placeholder="Enter your email address"
                disabled={isSubmitting}
              />
              {errors.email && <span className="error-text">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="phone">Phone Number *</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className={errors.phone ? 'error' : ''}
                placeholder="Enter your 10-digit phone number"
                disabled={isSubmitting}
              />
              {errors.phone && <span className="error-text">{errors.phone}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="message">Message *</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows="5"
                className={errors.message ? 'error' : ''}
                placeholder="Tell us about your project..."
                disabled={isSubmitting}
              ></textarea>
              {errors.message && <span className="error-text">{errors.message}</span>}
            </div>

            {/* Form Buttons */}
            <div className="form-buttons">
              <button 
                type="submit" 
                className={`btn btn-primary submit-btn ${isSubmitting ? 'loading' : ''}`}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <span className="spinner"></span>
                    Sending...
                  </>
                ) : (
                  'Send Message'
                )}
              </button>
              
              {/* Reset Button - Only show when form has data */}
              {(formData.name || formData.email || formData.phone || formData.message) && (
                <button 
                  type="button" 
                  className="btn btn-secondary reset-btn"
                  onClick={resetForm}
                  disabled={isSubmitting}
                >
                  Clear Form
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;