# EZ-TASK
This project is a responsive single-page React application for EZ-Task. It includes a modern homepage with a contact form that features front-end validation and API integration. The form checks for empty fields, valid email, and 10-digit phone number. On successful submission (201), it displays a success message.
